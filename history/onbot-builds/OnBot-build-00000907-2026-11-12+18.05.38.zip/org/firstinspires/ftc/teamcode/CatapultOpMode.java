package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.lynx.LynxModule;
import org.firstinspires.ftc.robotcore.external.State;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;

/**
 * Catapult TeleOp for a BARE 6000 rpm goBILDA motor (28 ticks per motor rev).
 *
 * FIRST RUN (calibrate, no code edits needed):
 *   1. Put the arm at HOME (down) and press START.
 *   2. Hold D-pad UP to creep the arm to where it should release the throw.
 *   3. Press X to save that spot as the release point.
 *   4. Press B to go home, then A to fire.
 *   Write the "Release (ticks)" number down and put it in DEFAULT_RELEASE_TICKS.
 *
 * Controls (gamepad 2 by default):
 *   A = fire | B = return home / clear fault | X = save release point
 *   D-pad up/down = slow jog
 */
@TeleOp(name = "TeleOp2026", group = "Test")
public class CatapultOpMode extends LinearOpMode {

    // ===== MECHANISM SETTINGS =====
    static final double MOTOR_TICKS_PER_REV = 28.0;  // bare 6000 rpm motor
    static final double EXTERNAL_GEAR_RATIO = 1.0;   // motor turns per arm turn (telemetry only)
    static final DcMotorSimple.Direction MOTOR_DIRECTION = DcMotorSimple.Direction.FORWARD;
    static final boolean USE_GAMEPAD_2 = true;

    // ===== POSITIONS (ticks) =====
    static final int HOME_POSITION         = 0;
    static final int DEFAULT_RELEASE_TICKS = 300;  // replace with your calibrated value
    static final int OVERSHOOT_COMP        = 0;    // raise if arm flies past release (cuts power earlier)
    static final int MAX_MARGIN            = 90;  // hard limit = release + this
    static final int HARD_MAX_TICKS        = 1500; // jog limit while calibrating
    static final int MIN_POSITION          = -30;  // jog-down limit

    // ===== POWER =====
    static final double FIRE_POWER   = 0.5;   // raise to 1.0 once it works
    static final double RETURN_POWER = 0.5;
    static final double JOG_POWER    = 0.30;  // slow so you can place the release point

    // ===== TOLERANCES / TIMING =====
    static final int    POSITION_TOL       = 10;
    static final int    HOME_READY_TOL     = 40;
    static final double FIRE_HOLD_SEC      = 0.20;
    static final double FIRE_TIMEOUT_SEC   = 3.0;
    static final double RETURN_TIMEOUT_SEC = 5.0;

    // ===== STALL DETECTION (high current AND not moving) =====
    static final double STALL_CURRENT_A = 8.0;   // stall of this motor is ~9.2 A
    static final double STALL_TIME_SEC  = 0.50;
    static final int    STALL_MOVE_TICKS = 3;

    private DcMotorEx catapult;
    private Gamepad pad;

    private final ElapsedTime timer = new ElapsedTime();
    private final ElapsedTime stallTimer = new ElapsedTime();
    private int lastStallPos = 0;
    private int releasePos = DEFAULT_RELEASE_TICKS;

    private enum State { IDLE, FIRING, HOLD, RETURNING, MANUAL, FAULT }
    private State state = State.IDLE;
    private String faultMessage = "";

    @Override
    public void runOpMode() {
        catapult = hardwareMap.get(DcMotorEx.class, "catapult");
        pad = USE_GAMEPAD_2 ? gamepad2 : gamepad1;

        for (LynxModule hub : hardwareMap.getAll(LynxModule.class)) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }

        catapult.setDirection(MOTOR_DIRECTION);
        catapult.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        catapult.setTargetPositionTolerance(POSITION_TOL);

        telemetry.addLine("Put the arm at HOME (down), then press START.");
        telemetry.update();

        waitForStart();
        if (isStopRequested()) return;

        catapult.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        catapult.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        boolean aPrev = false, bPrev = false, xPrev = false;

        while (opModeIsActive()) {
            int pos = catapult.getCurrentPosition();
            boolean a = pad.a, b = pad.b, x = pad.x;

            // ----- Buttons (edge detected) -----
            if (a && !aPrev && state == State.IDLE) {
                if (isAtHome(pos)) startFire(pos);
            }
            if (b && !bPrev) startReturn(pos);
            if (x && !xPrev && (state == State.IDLE || state == State.MANUAL)) {
                if (pos > HOME_POSITION + 10 && pos <= HARD_MAX_TICKS) releasePos = pos;
            }
            aPrev = a; bPrev = b; xPrev = x;

            // ----- Manual jog -----
            if (state == State.IDLE || state == State.MANUAL) {
                if (pad.dpad_up && pos < HARD_MAX_TICKS) {
                    manualJog(JOG_POWER, pos);
                } else if (pad.dpad_down && pos > MIN_POSITION) {
                    manualJog(-JOG_POWER, pos);
                } else if (state == State.MANUAL) {
                    stopMotor();
                    state = State.IDLE;
                }
            }

            // ----- State machine -----
            switch (state) {
                case FIRING:
                    if (pos >= releasePos - OVERSHOOT_COMP) {
                        catapult.setPower(0);   // BRAKE mode stops it
                        timer.reset();
                        state = State.HOLD;
                    } else if (pos >= releasePos + MAX_MARGIN) {
                        fault("Travel limit reached");
                    } else if (timer.seconds() > FIRE_TIMEOUT_SEC) {
                        fault("Fire timeout - check direction/encoder");
                    } else if (isStalled(pos)) {
                        fault("Stall while firing - arm jammed?");
                    }
                    break;

                case HOLD:
                    if (timer.seconds() >= FIRE_HOLD_SEC) startReturn(pos);
                    break;

                case RETURNING:
                    if (Math.abs(pos - HOME_POSITION) <= POSITION_TOL) {
                        stopMotor();
                        state = State.IDLE;
                    } else if (timer.seconds() > RETURN_TIMEOUT_SEC) {
                        fault("Return timeout");
                    } else if (isStalled(pos)) {
                        fault("Stall while returning");
                    }
                    break;

                case MANUAL:
                    if (isStalled(pos)) fault("Stall while jogging");
                    break;

                default:
                    break;
            }

            // ----- Telemetry -----
            telemetry.addData("State", state);
            if (state == State.FAULT) {
                telemetry.addData("FAULT", faultMessage);
                telemetry.addLine("Press B to return home and clear");
            }
            telemetry.addData("Ready to fire", state == State.IDLE && isAtHome(pos));
            telemetry.addData("Position (ticks)", pos);
            telemetry.addData("Release (ticks)", releasePos);
            telemetry.addData("Arm angle (deg)", "%.1f",
                    pos / (MOTOR_TICKS_PER_REV * EXTERNAL_GEAR_RATIO) * 360.0);
            telemetry.addData("Current (A)", "%.2f", catapult.getCurrent(CurrentUnit.AMPS));
            telemetry.addLine("A fire | B home | X save release | DPAD jog");
            telemetry.update();
        }

        catapult.setPower(0);
    }

    // ===== Helpers =====

    private void startFire(int pos) {
        catapult.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        catapult.setPower(FIRE_POWER);
        timer.reset();
        resetStall(pos);
        state = State.FIRING;
    }

    private void startReturn(int pos) {
        catapult.setTargetPosition(HOME_POSITION);
        catapult.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        catapult.setPower(RETURN_POWER);
        timer.reset();
        resetStall(pos);
        state = State.RETURNING;
    }

    private void manualJog(double power, int pos) {
        catapult.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        catapult.setPower(power);
        if (state != State.MANUAL) resetStall(pos);
        state = State.MANUAL;
    }

    private void stopMotor() {
        catapult.setPower(0);
        catapult.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    private void fault(String message) {
        stopMotor();
        faultMessage = message;
        state = State.FAULT;
    }

    private boolean isAtHome(int pos) {
        return Math.abs(pos - HOME_POSITION) <= HOME_READY_TOL;
    }

    private void resetStall(int pos) {
        lastStallPos = pos;
        stallTimer.reset();
    }

    private boolean isStalled(int pos) {
        double amps = catapult.getCurrent(CurrentUnit.AMPS);
        if (Math.abs(pos - lastStallPos) > STALL_MOVE_TICKS || amps < STALL_CURRENT_A) {
            resetStall(pos);
            return false;
        }
        return stallTimer.seconds() > STALL_TIME_SEC;
    }
}

